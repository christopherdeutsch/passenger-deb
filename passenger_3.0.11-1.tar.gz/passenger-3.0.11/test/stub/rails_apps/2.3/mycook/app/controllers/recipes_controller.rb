class RecipesController < ApplicationController
	def create
		
	end
end

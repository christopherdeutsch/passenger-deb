class ActiveRecord
	class Base
		def self.connected?
			return false
		end
	end
end

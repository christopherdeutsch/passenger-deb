// Some definitions for Doxygen.
/**
@defgroup Core Core Apache-related classes and functions
@defgroup Support Apache-independent support classes and function
*/

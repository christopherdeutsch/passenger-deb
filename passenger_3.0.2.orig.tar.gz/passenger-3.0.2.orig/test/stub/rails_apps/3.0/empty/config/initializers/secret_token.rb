# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
Rails.application.config.secret_token = '7a885cba0cf0fdb940bb23fedeac02049f21c8f69589dcc5d07797045dc65915cb92cb5970a26480cfc194491264522920ecce34541d10b4292188efb377681c'

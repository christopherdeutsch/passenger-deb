class BarController < ApplicationController
	def index
		render :text => 'bar 1!'
	end
end
